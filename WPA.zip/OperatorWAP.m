function [Offspring,Gbest,Pbest]    = OperatorWAP(Population,Gbest,w,S,beta,Tmax)
% <single> <real> <large/none> <constrained/none>
%------------------------------- Reference --------------------------------
% 吴虎胜,张凤鸣,吴庐山.一种新的群体智能算法——狼群算法[J].
% 系统工程与电子技术,2013,35(11):2430-2438.DataType: 1
% https://chn.oversea.cnki.net/kcms/detail/detail.aspx?FileName=XTYD201311034&DbName=CJFQ2013
%---------------------------------------------------------------------------
    Problem = PROBLEM.Current();
    PopDec = Population.decs;
    PopObj = Population.objs;
    [N,D]  = size(PopDec);
           
    GbestDec = Gbest.decs;                   % 头狼
    GbestObj = Gbest.objs; 
 
    % 探狼游走
    Stepa = abs(Problem.upper - Problem.lower)/S;
    for k = 1:Tmax% 最大游走次数
        for i = 1: N
            if PopObj(i,:) < GbestObj
                GbestDec = PopDec(i,:);
                GbestObj = PopObj(i,:);
                break;
            else
                h = randi([N/2,N],1); % 随机探索次数
                tempPopDec = PopDec(i,:);
                tempPopObj = PopObj(i,:);
                for p = 1: h
                    PopDecp =  PopDec(i,:) + sin(2*pi*p/h).* Stepa;
                    PopObjp =  Problem.CalObj(PopDec(i,:));
                    if PopObjp < PopObj(i,:)
                        tempPopDec = PopDecp;
                        tempPopObj = PopObjp;
                    end
                end
                PopDec(i,:) = tempPopDec;
                PopObj(i,:) = tempPopObj;
            end
            if PopObj(i,:) < GbestObj
                GbestDec = PopDec(i,:);
                GbestObj = PopObj(i,:);
            end
        end
    end
    
    % 头狼召唤，猛狼奔袭
    Dnear = (1/D*w)*sum(abs(Problem.upper - Problem.lower));
    Stepb = 2.*abs(Problem.upper - Problem.lower)./S;
    Stepc = abs(Problem.upper - Problem.lower)./S/2;
            
    for mp = 1:N
        dis = norm(GbestDec-PopDec(mp,:));
        if dis > Dnear
            tempMPopDec = PopDec(mp,:) + Stepb.*(GbestDec-PopDec(mp,:))./abs(GbestDec-PopDec(mp,:));
            tempMPopObj =  Problem.CalObj(tempMPopDec);
            
            if tempMPopObj < PopObj(mp,:)
                PopDec(mp,:) = tempMPopDec;
                PopObj(mp,:) = tempMPopObj;
            end
            if PopObj(mp,:) < GbestObj
                GbestDec = PopDec(mp,:);
                GbestObj = PopObj(mp,:);
            end
        elseif dis <= Dnear && dis ~= 0
            % 围攻
            tempLPopDec = PopDec(mp,:) + randi([-1,1],1,D).*Stepc.*abs(GbestDec-PopDec(mp,:));
            tempLPopObj =  Problem.CalObj(tempLPopDec);
            if tempLPopObj < PopObj(mp,:)
                PopDec(mp,:) = tempLPopDec;
                PopObj(mp,:) = tempLPopObj;
            end
        end
    end

    % 狼群排序，剔出R个劣质个体，随机产生R个新个体 
    [~,index] = sort(PopObj);
    PopDec    = PopDec(index,:);
    PopObj    = PopObj(index,:);
    R = randi([floor(N/(2*beta)),floor(N/beta)],1);
    Upper = Problem.upper;
    Lower = Problem.lower;
    NewOffDec =  repmat(Lower+(Upper-Lower).*rand(1,D),R,1);
    
    OffDec = [PopDec(1:N-R,:);NewOffDec];
    
    Offspring = SOLUTION(OffDec);
end