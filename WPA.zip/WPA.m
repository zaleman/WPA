classdef WPA < ALGORITHM
% <single> <real> <large/none> <constrained/none>
% Wolf Pack Algorithm
% a     --- 4 --- The Explore wolf proportion
% w     --- 500 --- Distance determination factor
% S     --- 1000 --- Step factor
% beta  --- 6 --- Updated scale factor
% Tmax --- 20 --- Maximum number of swims

%------------------------------- Reference --------------------------------
% 吴虎胜,张凤鸣,吴庐山.一种新的群体智能算法——狼群算法[J].
% 系统工程与电子技术,2013,35(11):2430-2438.DataType: 1
% https://chn.oversea.cnki.net/kcms/detail/detail.aspx?FileName=XTYD201311034&DbName=CJFQ2013

%------------------------------- Copyright --------------------------------
% Copyright (c) 2021 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    methods
        function main(Algorithm,Problem)
            %% Parameter setting
            [a,w,S,beta,Tmax] = Algorithm.ParameterSet(4,500,1000,6,20);% 10,500,20,6
            
            %% Generate random population
            Population = Problem.Initialization();
%             Problem = PROBLEM.Current();
%             Snum = randi([floor(Problem.N/(a+1)),floor(Problem.N/(a))],1);
%             Mnum = Problem.N-Snum-1;
            [~,best]   = min(FitnessSingle(Population));
            Gbest      = Population(best);
            %% Optimization
            while Algorithm.NotTerminated(Population)
                Population   = OperatorWAP(Population,Gbest,w,S,beta,Tmax);
                [Pbest,best] = min(FitnessSingle(Population));
                % 更新头狼
                if  Pbest < FitnessSingle(Gbest)
                    Gbest    = Population(best);
                end
            end
        end
    end
end